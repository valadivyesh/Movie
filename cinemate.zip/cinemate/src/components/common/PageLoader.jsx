import React from 'react'
import './PageLoader.css'

export default function PageLoader() {
  return (
    <div className="page-loader">
      <div className="loader-logo">
        <span>▶</span> CINE<span>MATE</span>
      </div>
      <div className="spinner" />
    </div>
  )
}
