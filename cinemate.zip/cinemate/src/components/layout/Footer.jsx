import React from 'react'
import { Link } from 'react-router-dom'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <Link to="/" className="footer__logo">
            <span>▶</span> CINE<span>MATE</span>
          </Link>
          <p>Your ultimate movie discovery platform. Powered by OMDb API.</p>
        </div>
        <div className="footer__links">
          <div className="footer__col">
            <h4>Browse</h4>
            <Link to="/">Home</Link>
            <Link to="/browse">All Movies</Link>
            <Link to="/search">Search</Link>
          </div>
          <div className="footer__col">
            <h4>Your Library</h4>
            <Link to="/favorites">Favorites</Link>
            <Link to="/watchlist">Watchlist</Link>
            <Link to="/profile">Profile</Link>
          </div>
        </div>
      </div>
      <div className="footer__bottom">
        <p>© {new Date().getFullYear()} CineMate. Built with React + OMDb API.</p>
      </div>
    </footer>
  )
}
