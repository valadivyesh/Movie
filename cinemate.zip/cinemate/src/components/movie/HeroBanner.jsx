import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { motion, AnimatePresence } from 'framer-motion'
import { loadHero } from '../../store/slices/moviesSlice'
import { toggleFavorite, toggleWatchlist } from '../../store/slices/userDataSlice'
import { getPosterUrl, truncate, getTrailerUrl } from '../../utils/helpers'
import './HeroBanner.css'

export default function HeroBanner() {
  const dispatch = useDispatch()
  const { hero, loading } = useSelector(s => s.movies)
  const { isAuthenticated } = useSelector(s => s.auth)
  const { favorites, watchlist } = useSelector(s => s.userData)
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    dispatch(loadHero())
  }, [])

  useEffect(() => {
    if (hero.length <= 1) return
    const t = setInterval(() => setCurrent(c => (c + 1) % hero.length), 6000)
    return () => clearInterval(t)
  }, [hero.length])

  if (loading.hero || !hero.length) {
    return <div className="hero-skeleton shimmer" />
  }

  const movie = hero[current]
  if (!movie) return null

  const isFav = favorites.some(m => m.imdbID === movie.imdbID)
  const isWatch = watchlist.some(m => m.imdbID === movie.imdbID)

  const handleFav = () => {
    if (isAuthenticated) dispatch(toggleFavorite({ imdbID: movie.imdbID, Title: movie.Title, Poster: movie.Poster, Year: movie.Year, Type: movie.Type }))
  }

  const handleWatch = () => {
    if (isAuthenticated) dispatch(toggleWatchlist({ imdbID: movie.imdbID, Title: movie.Title, Poster: movie.Poster, Year: movie.Year, Type: movie.Type }))
  }

  return (
    <div className="hero">
      <AnimatePresence mode="wait">
        <motion.div
          key={movie.imdbID}
          className="hero__bg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          <img src={getPosterUrl(movie.Poster)} alt={movie.Title} />
          <div className="hero__gradient" />
        </motion.div>
      </AnimatePresence>

      <div className="hero__content container">
        <AnimatePresence mode="wait">
          <motion.div
            key={movie.imdbID + 'content'}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            {movie.Genre && (
              <div className="hero__genres">
                {movie.Genre.split(',').slice(0, 3).map(g => (
                  <span key={g} className="tag">{g.trim()}</span>
                ))}
              </div>
            )}
            <h1 className="hero__title">{movie.Title}</h1>
            <div className="hero__meta">
              {movie.Year && <span>{movie.Year}</span>}
              {movie.Runtime && movie.Runtime !== 'N/A' && <span>{movie.Runtime}</span>}
              {movie.imdbRating && movie.imdbRating !== 'N/A' && (
                <span className="hero__rating">⭐ {movie.imdbRating}</span>
              )}
            </div>
            {movie.Plot && movie.Plot !== 'N/A' && (
              <p className="hero__plot">{truncate(movie.Plot, 200)}</p>
            )}
            <div className="hero__actions">
              <Link to={`/movie/${movie.imdbID}`} className="btn btn-primary hero-btn">
                ▶ View Details
              </Link>
              <a
                href={getTrailerUrl(movie.Title, movie.Year)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-ghost hero-btn"
              >
                🎬 Watch Trailer
              </a>
              {isAuthenticated && (
                <>
                  <button className={`btn-icon ${isFav ? 'fav-active' : ''}`} onClick={handleFav} title="Favorite">
                    {isFav ? '❤️' : '🤍'}
                  </button>
                  <button className={`btn-icon ${isWatch ? 'watch-active' : ''}`} onClick={handleWatch} title="Watchlist">
                    {isWatch ? '✅' : '➕'}
                  </button>
                </>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {hero.length > 1 && (
        <div className="hero__dots">
          {hero.map((_, i) => (
            <button
              key={i}
              className={`hero__dot ${i === current ? 'active' : ''}`}
              onClick={() => setCurrent(i)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
