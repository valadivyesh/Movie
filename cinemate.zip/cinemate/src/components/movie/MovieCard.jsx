import React from 'react'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { motion } from 'framer-motion'
import { toggleFavorite, toggleWatchlist } from '../../store/slices/userDataSlice'
import { getPosterUrl, truncate } from '../../utils/helpers'
import './MovieCard.css'

export default function MovieCard({ movie, index = 0 }) {
  const dispatch = useDispatch()
  const { isAuthenticated } = useSelector(s => s.auth)
  const { favorites, watchlist } = useSelector(s => s.userData)

  if (!movie || !movie.imdbID) return null

  const isFav = favorites.some(m => m.imdbID === movie.imdbID)
  const isWatched = watchlist.some(m => m.imdbID === movie.imdbID)

  const handleFav = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (isAuthenticated) dispatch(toggleFavorite(movie))
  }

  const handleWatch = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (isAuthenticated) dispatch(toggleWatchlist(movie))
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
    >
      <Link to={`/movie/${movie.imdbID}`} className="movie-card">
        <div className="movie-card__poster">
          <img
            src={getPosterUrl(movie.Poster)}
            alt={movie.Title}
            loading="lazy"
            onError={e => { e.target.src = `https://via.placeholder.com/300x445/16161e/555566?text=No+Poster` }}
          />
          <div className="movie-card__overlay">
            <div className="movie-card__actions">
              {isAuthenticated && (
                <>
                  <button
                    className={`card-action-btn ${isFav ? 'active' : ''}`}
                    onClick={handleFav}
                    title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    {isFav ? '❤️' : '🤍'}
                  </button>
                  <button
                    className={`card-action-btn ${isWatched ? 'active' : ''}`}
                    onClick={handleWatch}
                    title={isWatched ? 'Remove from watchlist' : 'Add to watchlist'}
                  >
                    {isWatched ? '✅' : '➕'}
                  </button>
                </>
              )}
              <Link to={`/movie/${movie.imdbID}`} className="card-action-btn play-btn">▶</Link>
            </div>
          </div>
          {movie.Type && <span className="movie-card__type">{movie.Type}</span>}
        </div>
        <div className="movie-card__info">
          <h3 className="movie-card__title">{truncate(movie.Title, 40)}</h3>
          <p className="movie-card__year">{movie.Year}</p>
        </div>
      </Link>
    </motion.div>
  )
}
