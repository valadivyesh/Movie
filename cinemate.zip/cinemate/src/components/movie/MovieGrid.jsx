import React from 'react'
import MovieCard from './MovieCard'
import SkeletonCard from '../common/SkeletonCard'
import './MovieGrid.css'

export default function MovieGrid({ movies, loading, count = 10 }) {
  if (loading) {
    return (
      <div className="movie-grid">
        {Array.from({ length: count }).map((_, i) => <SkeletonCard key={i} />)}
      </div>
    )
  }

  if (!movies || movies.length === 0) return null

  return (
    <div className="movie-grid">
      {movies.map((movie, i) => (
        <MovieCard key={movie.imdbID || i} movie={movie} index={i} />
      ))}
    </div>
  )
}
