import React from 'react'
import { Link } from 'react-router-dom'
import MovieCard from './MovieCard'
import SkeletonCard from '../common/SkeletonCard'
import './MovieSection.css'

export default function MovieSection({ title, movies, loading, viewAllLink }) {
  return (
    <section className="movie-section">
      <div className="section-header">
        <h2 className="section-title">{title}</h2>
        {viewAllLink && <Link to={viewAllLink} className="section-more">View All →</Link>}
      </div>
      <div className="section-row">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
          : movies?.slice(0, 8).map((movie, i) => (
              <MovieCard key={movie.imdbID || i} movie={movie} index={i} />
            ))
        }
      </div>
    </section>
  )
}
