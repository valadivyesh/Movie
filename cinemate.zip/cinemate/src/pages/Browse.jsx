import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { loadBrowse, setBrowseKeyword, setBrowsePage } from '../store/slices/moviesSlice'
import MovieGrid from '../components/movie/MovieGrid'
import './Browse.css'

const CATEGORIES = [
  { label: 'Action', key: 'action' },
  { label: 'Comedy', key: 'comedy' },
  { label: 'Horror', key: 'horror' },
  { label: 'Drama', key: 'drama' },
  { label: 'Sci-Fi', key: 'science fiction' },
  { label: 'Thriller', key: 'thriller' },
  { label: 'Romance', key: 'romance' },
  { label: 'Animation', key: 'animation' },
  { label: 'Crime', key: 'crime' },
  { label: 'Marvel', key: 'Marvel' },
  { label: 'DC', key: 'Batman' },
  { label: 'Star Wars', key: 'Star Wars' },
]

export default function Browse() {
  const dispatch = useDispatch()
  const [searchParams] = useSearchParams()
  const { browse, browsePage, browseTotal, browseKeyword, loading } = useSelector(s => s.movies)
  const [activeKey, setActiveKey] = useState(searchParams.get('k') || browseKeyword || 'action')

  const totalPages = Math.ceil(browseTotal / 10)

  useEffect(() => {
    const k = searchParams.get('k') || activeKey
    setActiveKey(k)
    dispatch(setBrowseKeyword(k))
    dispatch(loadBrowse({ keyword: k, page: 1 }))
  }, [searchParams.get('k')])

  const handleCategory = (key) => {
    setActiveKey(key)
    dispatch(setBrowseKeyword(key))
    dispatch(setBrowsePage(1))
    dispatch(loadBrowse({ keyword: key, page: 1 }))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handlePage = (p) => {
    dispatch(setBrowsePage(p))
    dispatch(loadBrowse({ keyword: activeKey, page: p }))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="browse container">
      <motion.div
        className="browse__header"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="browse__title">Browse Movies</h1>
        <p className="browse__sub">Explore by genre and category</p>
      </motion.div>

      <div className="browse__chips">
        {CATEGORIES.map(c => (
          <button
            key={c.key}
            className={`chip ${activeKey === c.key ? 'chip--active' : ''}`}
            onClick={() => handleCategory(c.key)}
          >
            {c.label}
          </button>
        ))}
      </div>

      {browseTotal > 0 && (
        <p className="browse__count">{browseTotal.toLocaleString()} results for <strong>"{activeKey}"</strong></p>
      )}

      <MovieGrid movies={browse} loading={loading.browse} />

      {totalPages > 1 && (
        <div className="pagination">
          <button
            className="btn btn-ghost"
            onClick={() => handlePage(browsePage - 1)}
            disabled={browsePage <= 1}
          >
            ← Prev
          </button>
          <div className="pagination__pages">
            {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => i + 1).map(p => (
              <button
                key={p}
                className={`page-btn ${p === browsePage ? 'active' : ''}`}
                onClick={() => handlePage(p)}
              >
                {p}
              </button>
            ))}
          </div>
          <button
            className="btn btn-ghost"
            onClick={() => handlePage(browsePage + 1)}
            disabled={browsePage >= totalPages}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  )
}
