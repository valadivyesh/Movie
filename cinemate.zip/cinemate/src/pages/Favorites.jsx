import React from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import MovieGrid from '../components/movie/MovieGrid'
import './Library.css'

export default function Favorites() {
  const { favorites } = useSelector(s => s.userData)

  return (
    <div className="library container">
      <motion.div
        className="library__header"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div>
          <h1 className="library__title">My Favorites</h1>
          <p className="library__sub">{favorites.length} movie{favorites.length !== 1 ? 's' : ''} saved</p>
        </div>
      </motion.div>

      {favorites.length === 0 ? (
        <div className="empty-state">
          <div className="icon">❤️</div>
          <h3>No favorites yet</h3>
          <p>Browse movies and tap the heart icon to add them here.</p>
          <Link to="/browse" className="btn btn-primary" style={{ marginTop: 16 }}>Browse Movies</Link>
        </div>
      ) : (
        <MovieGrid movies={favorites} loading={false} />
      )}
    </div>
  )
}
