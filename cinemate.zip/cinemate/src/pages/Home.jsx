import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { loadTrending, loadPopular, loadTopRated } from '../store/slices/moviesSlice'
import HeroBanner from '../components/movie/HeroBanner'
import MovieSection from '../components/movie/MovieSection'
import './Home.css'

export default function Home() {
  const dispatch = useDispatch()
  const { trending, popular, topRated, loading } = useSelector(s => s.movies)

  useEffect(() => {
    dispatch(loadTrending())
    dispatch(loadPopular())
    dispatch(loadTopRated())
  }, [])

  return (
    <div className="home">
      <HeroBanner />
      <div className="home__content container">
        <MovieSection
          title="Trending Now"
          movies={trending}
          loading={loading.trending}
          viewAllLink="/browse?k=Avengers"
        />
        <MovieSection
          title="Popular Movies"
          movies={popular}
          loading={loading.popular}
          viewAllLink="/browse?k=action"
        />
        <MovieSection
          title="Top Rated"
          movies={topRated}
          loading={loading.topRated}
          viewAllLink="/browse?k=Inception"
        />
      </div>
    </div>
  )
}
