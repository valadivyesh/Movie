import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { motion } from 'framer-motion'
import { getMovieById } from '../services/movieApi'
import { toggleFavorite, toggleWatchlist } from '../store/slices/userDataSlice'
import { getPosterUrl, getRatingColor, formatRuntime, getGenreList, formatVotes, getTrailerUrl, getActorList } from '../utils/helpers'
import './MovieDetail.css'

export default function MovieDetail() {
  const { id } = useParams()
  const dispatch = useDispatch()
  const { isAuthenticated } = useSelector(s => s.auth)
  const { favorites, watchlist } = useSelector(s => s.userData)
  const [movie, setMovie] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const isFav = favorites.some(m => m.imdbID === id)
  const isWatch = watchlist.some(m => m.imdbID === id)

  useEffect(() => {
    setLoading(true)
    setError(null)
    getMovieById(id)
      .then(data => { setMovie(data); setLoading(false) })
      .catch(e => { setError(e.message); setLoading(false) })
  }, [id])

  const handleFav = () => {
    if (!isAuthenticated || !movie) return
    dispatch(toggleFavorite({ imdbID: movie.imdbID, Title: movie.Title, Poster: movie.Poster, Year: movie.Year, Type: movie.Type }))
  }

  const handleWatch = () => {
    if (!isAuthenticated || !movie) return
    dispatch(toggleWatchlist({ imdbID: movie.imdbID, Title: movie.Title, Poster: movie.Poster, Year: movie.Year, Type: movie.Type }))
  }

  if (loading) {
    return (
      <div className="detail-loading container">
        <div className="detail-skeleton">
          <div className="skeleton-poster-lg shimmer" />
          <div className="detail-skeleton-info">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="skeleton-line shimmer" style={{ width: `${80 - i * 10}%`, height: 20 + i * 4 }} />
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error || !movie) {
    return (
      <div className="container">
        <div className="empty-state" style={{ marginTop: 60 }}>
          <div className="icon">🎬</div>
          <h3>Movie not found</h3>
          <p>{error || 'Could not load movie details.'}</p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: 12 }}>Go Home</Link>
        </div>
      </div>
    )
  }

  const genres = getGenreList(movie.Genre)
  const actors = getActorList(movie.Actors)
  const runtime = formatRuntime(movie.Runtime)

  return (
    <div className="detail">
      <div className="detail__bg">
        <img src={getPosterUrl(movie.Poster)} alt="" aria-hidden="true" />
        <div className="detail__bg-overlay" />
      </div>

      <div className="detail__content container">
        <motion.div
          className="detail__grid"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="detail__poster-col">
            <div className="detail__poster">
              <img src={getPosterUrl(movie.Poster)} alt={movie.Title} />
            </div>
            {isAuthenticated && (
              <div className="detail__poster-actions">
                <button className={`btn ${isFav ? 'btn-primary' : 'btn-ghost'} detail-action-btn`} onClick={handleFav}>
                  {isFav ? '❤️ Favorited' : '🤍 Favorite'}
                </button>
                <button className={`btn ${isWatch ? 'btn-primary' : 'btn-ghost'} detail-action-btn`} onClick={handleWatch}>
                  {isWatch ? '✅ In Watchlist' : '➕ Watchlist'}
                </button>
              </div>
            )}
          </div>

          <div className="detail__info">
            <div className="detail__breadcrumb">
              <Link to="/">Home</Link> / <span>{movie.Title}</span>
            </div>

            {genres.length > 0 && (
              <div className="detail__genres">
                {genres.map(g => <span key={g} className="tag">{g}</span>)}
              </div>
            )}

            <h1 className="detail__title">{movie.Title}</h1>

            <div className="detail__meta-row">
              {movie.Year && movie.Year !== 'N/A' && <span className="meta-chip">{movie.Year}</span>}
              {runtime && <span className="meta-chip">{runtime}</span>}
              {movie.Rated && movie.Rated !== 'N/A' && <span className="meta-chip">{movie.Rated}</span>}
              {movie.Type && <span className="meta-chip">{movie.Type}</span>}
            </div>

            {movie.imdbRating && movie.imdbRating !== 'N/A' && (
              <div className="detail__rating">
                <div className="rating-score" style={{ color: getRatingColor(movie.imdbRating) }}>
                  ⭐ {movie.imdbRating}
                  <span>/10</span>
                </div>
                {movie.imdbVotes && movie.imdbVotes !== 'N/A' && (
                  <span className="rating-votes">{formatVotes(movie.imdbVotes)} votes</span>
                )}
              </div>
            )}

            {movie.Plot && movie.Plot !== 'N/A' && (
              <p className="detail__plot">{movie.Plot}</p>
            )}

            <div className="detail__actions">
              <a
                href={getTrailerUrl(movie.Title, movie.Year)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
              >
                🎬 Watch Trailer
              </a>
              <a
                href={`https://www.imdb.com/title/${movie.imdbID}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-ghost"
              >
                IMDb Page
              </a>
            </div>

            <div className="detail__credits">
              {actors.length > 0 && (
                <div className="credit-row">
                  <span className="credit-label">Cast</span>
                  <span>{actors.join(', ')}</span>
                </div>
              )}
              {movie.Director && movie.Director !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Director</span>
                  <span>{movie.Director}</span>
                </div>
              )}
              {movie.Writer && movie.Writer !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Writer</span>
                  <span>{movie.Writer.split(',').slice(0, 2).join(', ')}</span>
                </div>
              )}
              {movie.Language && movie.Language !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Language</span>
                  <span>{movie.Language}</span>
                </div>
              )}
              {movie.Country && movie.Country !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Country</span>
                  <span>{movie.Country}</span>
                </div>
              )}
              {movie.Awards && movie.Awards !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Awards</span>
                  <span>{movie.Awards}</span>
                </div>
              )}
              {movie.BoxOffice && movie.BoxOffice !== 'N/A' && (
                <div className="credit-row">
                  <span className="credit-label">Box Office</span>
                  <span>{movie.BoxOffice}</span>
                </div>
              )}
            </div>

            {movie.Ratings && movie.Ratings.length > 0 && (
              <div className="detail__scores">
                {movie.Ratings.map(r => (
                  <div key={r.Source} className="score-item">
                    <span className="score-value">{r.Value}</span>
                    <span className="score-source">{r.Source.replace('Internet Movie Database', 'IMDb').replace('Rotten Tomatoes', 'RT')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
