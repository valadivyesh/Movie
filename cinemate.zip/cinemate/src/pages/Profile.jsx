import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { logout, updateProfile } from '../store/slices/authSlice'
import { clearUserData } from '../store/slices/userDataSlice'
import './Profile.css'

export default function Profile() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { user } = useSelector(s => s.auth)
  const { favorites, watchlist } = useSelector(s => s.userData)
  const [editMode, setEditMode] = useState(false)
  const [name, setName] = useState(user?.name || '')
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    if (name.trim()) {
      dispatch(updateProfile({ name: name.trim() }))
      setSaved(true)
      setEditMode(false)
      setTimeout(() => setSaved(false), 2000)
    }
  }

  const handleLogout = () => {
    dispatch(logout())
    dispatch(clearUserData())
    navigate('/')
  }

  const stats = [
    { label: 'Favorites', value: favorites.length, emoji: '❤️' },
    { label: 'Watchlist', value: watchlist.length, emoji: '📋' },
    { label: 'Account', value: 'Active', emoji: '✅' },
  ]

  return (
    <div className="profile container">
      <motion.div
        className="profile__card"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="profile__avatar-row">
          <div className="profile__avatar">
            {user?.name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div>
            <h1 className="profile__name">{user?.name}</h1>
            <p className="profile__email">{user?.email}</p>
          </div>
        </div>

        <div className="profile__stats">
          {stats.map(s => (
            <div key={s.label} className="stat-box">
              <span className="stat-emoji">{s.emoji}</span>
              <span className="stat-value">{s.value}</span>
              <span className="stat-label">{s.label}</span>
            </div>
          ))}
        </div>

        <div className="profile__section">
          <h2 className="profile__section-title">Edit Profile</h2>
          {editMode ? (
            <div className="profile__edit">
              <input
                className="profile__input"
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Your name"
              />
              <div className="profile__edit-actions">
                <button className="btn btn-primary" onClick={handleSave}>Save Changes</button>
                <button className="btn btn-ghost" onClick={() => setEditMode(false)}>Cancel</button>
              </div>
            </div>
          ) : (
            <button className="btn btn-ghost" onClick={() => setEditMode(true)}>Edit Name</button>
          )}
          {saved && <p className="profile__saved">✅ Profile updated!</p>}
        </div>

        <div className="profile__section">
          <h2 className="profile__section-title">Account</h2>
          <button className="btn btn-ghost danger-btn" onClick={handleLogout}>Sign Out</button>
        </div>
      </motion.div>
    </div>
  )
}
