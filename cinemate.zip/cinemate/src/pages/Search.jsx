import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { motion } from 'framer-motion'
import { performSearch, setQuery, setPage, setType } from '../store/slices/searchSlice'
import MovieGrid from '../components/movie/MovieGrid'
import './Search.css'

const TYPES = [
  { label: 'All', value: '' },
  { label: 'Movies', value: 'movie' },
  { label: 'Series', value: 'series' },
  { label: 'Episodes', value: 'episode' },
]

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams()
  const dispatch = useDispatch()
  const { results, total, page, loading, error, type } = useSelector(s => s.search)
  const [inputVal, setInputVal] = useState(searchParams.get('q') || '')

  const totalPages = Math.ceil(total / 10)

  useEffect(() => {
    const q = searchParams.get('q')
    if (q) {
      dispatch(setQuery(q))
      dispatch(performSearch({ query: q, page: 1, type }))
    }
  }, [searchParams.get('q')])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (inputVal.trim()) {
      setSearchParams({ q: inputVal.trim() })
    }
  }

  const handleType = (t) => {
    dispatch(setType(t))
    const q = searchParams.get('q')
    if (q) dispatch(performSearch({ query: q, page: 1, type: t }))
  }

  const handlePage = (p) => {
    dispatch(setPage(p))
    const q = searchParams.get('q')
    if (q) dispatch(performSearch({ query: q, page: p, type }))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const q = searchParams.get('q')

  return (
    <div className="search-page container">
      <motion.div
        className="search-header"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="search-title">Search Movies</h1>
        <form className="search-form" onSubmit={handleSubmit}>
          <input
            type="text"
            className="search-input"
            placeholder="Search for movies, series..."
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            autoFocus
          />
          <button type="submit" className="btn btn-primary search-btn">Search</button>
        </form>

        <div className="search-types">
          {TYPES.map(t => (
            <button
              key={t.value}
              className={`chip ${type === t.value ? 'chip--active' : ''}`}
              onClick={() => handleType(t.value)}
            >
              {t.label}
            </button>
          ))}
        </div>
      </motion.div>

      {q && (
        <p className="search-results-info">
          {loading ? 'Searching...' : error ? '' : total > 0 ? `${total.toLocaleString()} results for "${q}"` : `No results for "${q}"`}
        </p>
      )}

      {error && (
        <div className="empty-state">
          <div className="icon">🔍</div>
          <h3>No results found</h3>
          <p>Try different keywords or check your spelling.</p>
        </div>
      )}

      <MovieGrid movies={results} loading={loading} />

      {totalPages > 1 && (
        <div className="pagination" style={{ marginTop: 40 }}>
          <button className="btn btn-ghost" onClick={() => handlePage(page - 1)} disabled={page <= 1}>← Prev</button>
          <div className="pagination__pages">
            {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => i + 1).map(p => (
              <button key={p} className={`page-btn ${p === page ? 'active' : ''}`} onClick={() => handlePage(p)}>{p}</button>
            ))}
          </div>
          <button className="btn btn-ghost" onClick={() => handlePage(page + 1)} disabled={page >= totalPages}>Next →</button>
        </div>
      )}

      {!q && !loading && (
        <div className="empty-state">
          <div className="icon">🎬</div>
          <h3>Find your next favorite movie</h3>
          <p>Type a movie title, actor, or genre above to get started.</p>
        </div>
      )}
    </div>
  )
}
