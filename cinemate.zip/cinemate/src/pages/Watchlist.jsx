import React from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import MovieGrid from '../components/movie/MovieGrid'
import './Library.css'

export default function Watchlist() {
  const { watchlist } = useSelector(s => s.userData)

  return (
    <div className="library container">
      <motion.div
        className="library__header"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div>
          <h1 className="library__title">My Watchlist</h1>
          <p className="library__sub">{watchlist.length} movie{watchlist.length !== 1 ? 's' : ''} to watch</p>
        </div>
      </motion.div>

      {watchlist.length === 0 ? (
        <div className="empty-state">
          <div className="icon">📋</div>
          <h3>Watchlist is empty</h3>
          <p>Add movies with the ➕ button to track what you want to watch.</p>
          <Link to="/browse" className="btn btn-primary" style={{ marginTop: 16 }}>Browse Movies</Link>
        </div>
      ) : (
        <MovieGrid movies={watchlist} loading={false} />
      )}
    </div>
  )
}
