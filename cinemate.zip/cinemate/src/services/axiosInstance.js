import axios from 'axios'

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_OMDB_BASE_URL,
  params: {
    apikey: import.meta.env.VITE_OMDB_API_KEY
  }
})

apiClient.interceptors.request.use(
  (config) => config,
  (error) => Promise.reject(error)
)

apiClient.interceptors.response.use(
  (response) => {
    if (response.data.Response === 'False') {
      return Promise.reject(new Error(response.data.Error || 'API error'))
    }
    return response
  },
  (error) => Promise.reject(error)
)

export default apiClient
