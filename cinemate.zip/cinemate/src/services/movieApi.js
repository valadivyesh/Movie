import apiClient from './axiosInstance'

export const searchMovies = async (query, page = 1, type = '') => {
  const params = { s: query, page, type: type || undefined }
  const res = await apiClient.get('/', { params })
  return res.data
}

export const getMovieById = async (imdbId) => {
  const res = await apiClient.get('/', { params: { i: imdbId, plot: 'full' } })
  return res.data
}

export const getMovieByTitle = async (title) => {
  const res = await apiClient.get('/', { params: { t: title, plot: 'full' } })
  return res.data
}

export const fetchMoviesByKeyword = async (keyword, page = 1) => {
  const res = await apiClient.get('/', { params: { s: keyword, page } })
  return res.data
}

const TRENDING_SEARCHES = [
  'Avengers', 'Batman', 'Spider-Man', 'Star Wars', 'James Bond',
  'Fast Furious', 'Mission Impossible', 'Transformers', 'Iron Man', 'Thor'
]

const POPULAR_SEARCHES = [
  'Comedy', 'Romance', 'Horror', 'Thriller', 'Drama',
  'Action', 'Sci-Fi', 'Adventure', 'Crime', 'Fantasy'
]

const TOP_RATED_SEARCHES = [
  'Godfather', 'Inception', 'Interstellar', 'Matrix',
  'Joker', 'Pulp Fiction', 'Forrest Gump', 'Shawshank'
]

export const fetchTrending = async (page = 1) => {
  const keyword = TRENDING_SEARCHES[Math.floor(Math.random() * TRENDING_SEARCHES.length)]
  return fetchMoviesByKeyword(keyword, page)
}

export const fetchPopular = async (page = 1) => {
  const keyword = POPULAR_SEARCHES[Math.floor(Math.random() * POPULAR_SEARCHES.length)]
  return fetchMoviesByKeyword(keyword, page)
}

export const fetchTopRated = async (page = 1) => {
  const keyword = TOP_RATED_SEARCHES[Math.floor(Math.random() * TOP_RATED_SEARCHES.length)]
  return fetchMoviesByKeyword(keyword, page)
}

export const fetchHeroMovies = async () => {
  const titles = ['Inception', 'Interstellar', 'The Dark Knight', 'Avengers Endgame', 'Joker']
  const results = await Promise.allSettled(titles.map(t => getMovieByTitle(t)))
  return results
    .filter(r => r.status === 'fulfilled')
    .map(r => r.value)
    .filter(m => m.Poster && m.Poster !== 'N/A')
}
