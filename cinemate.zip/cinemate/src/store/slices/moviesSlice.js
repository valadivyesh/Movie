import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchTrending, fetchPopular, fetchTopRated, fetchHeroMovies, fetchMoviesByKeyword } from '../../services/movieApi'

export const loadTrending = createAsyncThunk('movies/loadTrending', async (_, { rejectWithValue }) => {
  try { return await fetchTrending() } catch (e) { return rejectWithValue(e.message) }
})

export const loadPopular = createAsyncThunk('movies/loadPopular', async (_, { rejectWithValue }) => {
  try { return await fetchPopular() } catch (e) { return rejectWithValue(e.message) }
})

export const loadTopRated = createAsyncThunk('movies/loadTopRated', async (_, { rejectWithValue }) => {
  try { return await fetchTopRated() } catch (e) { return rejectWithValue(e.message) }
})

export const loadHero = createAsyncThunk('movies/loadHero', async (_, { rejectWithValue }) => {
  try { return await fetchHeroMovies() } catch (e) { return rejectWithValue(e.message) }
})

export const loadBrowse = createAsyncThunk('movies/loadBrowse', async ({ keyword, page }, { rejectWithValue }) => {
  try { return await fetchMoviesByKeyword(keyword, page) } catch (e) { return rejectWithValue(e.message) }
})

const moviesSlice = createSlice({
  name: 'movies',
  initialState: {
    hero: [],
    trending: [],
    popular: [],
    topRated: [],
    browse: [],
    browsePage: 1,
    browseTotal: 0,
    browseKeyword: 'action',
    loading: {},
    error: {}
  },
  reducers: {
    setBrowseKeyword: (state, action) => {
      state.browseKeyword = action.payload
      state.browse = []
      state.browsePage = 1
    },
    setBrowsePage: (state, action) => {
      state.browsePage = action.payload
    }
  },
  extraReducers: (builder) => {
    const handle = (key, asyncThunk, transform) => {
      builder
        .addCase(asyncThunk.pending, (state) => { state.loading[key] = true; state.error[key] = null })
        .addCase(asyncThunk.fulfilled, (state, action) => {
          state.loading[key] = false
          if (transform) transform(state, action)
        })
        .addCase(asyncThunk.rejected, (state, action) => {
          state.loading[key] = false
          state.error[key] = action.payload
        })
    }

    handle('hero', loadHero, (state, action) => { state.hero = action.payload })
    handle('trending', loadTrending, (state, action) => { state.trending = action.payload.Search || [] })
    handle('popular', loadPopular, (state, action) => { state.popular = action.payload.Search || [] })
    handle('topRated', loadTopRated, (state, action) => { state.topRated = action.payload.Search || [] })
    handle('browse', loadBrowse, (state, action) => {
      state.browse = action.payload.Search || []
      state.browseTotal = parseInt(action.payload.totalResults || 0)
    })
  }
})

export const { setBrowseKeyword, setBrowsePage } = moviesSlice.actions
export default moviesSlice.reducer
